<template>
  <div>
    <!-- 닫기 버튼 -->
    <div class="text-right mb-4">
      <button
        class="px-4 py-1 text-sm text-gray-600 hover:underline"
        @click="goBackToBoard"
      >
        ← 목록으로 돌아가기
      </button>
    </div>

    <div v-if="article" class="bg-white p-6 rounded shadow mb-10">
      <!-- 제목 + 작성자 -->
      <div class="flex justify-between items-center mb-2">
        <h2 class="text-2xl font-bold">{{ article.title }}</h2>
        <span class="text-gray-500 text-sm">작성자 : {{ article.userNickname }}</span>
      </div>

      <!-- ✨ 수정/삭제 버튼 -->
      <div v-if="isMyArticle" class="flex justify-end gap-2 mb-2">
        <button
          @click="goToEdit"
          class="px-4 py-1 text-sm text-white bg-blue-600 rounded hover:bg-blue-700"
        >
          수정
        </button>
        <button
          @click="deleteArticle"
          class="px-4 py-1 text-sm text-white bg-red-600 rounded hover:bg-red-700"
        >
          삭제
        </button>
      </div>

      <!-- 내용 + 대표 이미지 -->
      <div class="flex flex-col md:flex-row gap-4 mt-4">
        <div class="flex-1 whitespace-pre-line text-gray-800">
          내용 : {{ article.content }}
        </div>
        <img v-if="article.imageUrl" :src="getImageUrl(article.imageUrl)" alt="대표 이미지"
          class="w-full md:w-80 h-auto rounded object-cover shadow" />
      </div>

      <!-- 추가 첨부 이미지 -->
      <div v-if="additionalImages.length" class="mt-6">
        <h4 class="font-semibold mb-2">첨부 이미지</h4>
        <div class="grid grid-cols-2 md:grid-cols-3 gap-4">
          <img v-for="(img, index) in additionalImages" :key="index" :src="getImageUrl(img.filePath)"
            :alt="img.originalName" class="w-full h-40 object-cover rounded shadow" />
        </div>
      </div>

      <!-- 좋아요/싫어요/조회수 -->
      <div class="flex items-center gap-3 text-gray-500 text-sm mt-4">
        <LikeDislikeButtons
          contentType="ARTICLE"
          :contentId="articleId"
          :likeCount="article.likeCount"
          :dislikeCount="article.dislikeCount"
          :myReaction="article.myReaction"
          :onUpdated="fetchArticle"
        />
        <span class="flex items-center gap-1"> 👁️ 조회수 {{ article.viewCnt }} </span>
      </div>

      <!-- 댓글 입력 -->
      <h3 class="mt-8 text-lg font-semibold">댓글</h3>

      <CommentInput
        :parentCommentId="null"
        :onSubmit="loadComments"
        targetType="ARTICLE"
        :targetId="articleId"
      />

      <!-- 댓글 목록 -->
      <div v-if="comments.length">
        <CommentItem
          v-for="comment in comments"
          :key="comment.commentId"
          :comment="comment"
          :onReload="loadComments"
          targetType="ARTICLE"
          :targetId="articleId"
        />
      </div>
      <div v-else>
        <p class="text-sm text-gray-500 mt-2">아직 댓글이 없습니다.</p>
      </div>
    </div>
  </div>
</template>

<script setup>
import { ref, onMounted, watch, computed } from 'vue'
import { useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/stores/auth'
import axios from 'axios'
import CommentItem from '@/components/CommentItem.vue'
import CommentInput from '@/components/CommentInput.vue'
import LikeDislikeButtons from '@/components/LikeDislikeButtons.vue'

// 📌 라우터에서 articleId와 boardId 추출
const route = useRoute()
const router = useRouter()

const articleId = Number(route.params.articleId)
const boardId = Number(route.params.boardId)

const article = ref(null)
const additionalImages = ref([])
const comments = ref([])

const auth = useAuthStore()
const currentUser = computed(() => auth.user)


// 권한 확인
const isMyArticle = computed(() => {
  return article.value?.userId === currentUser.value?.userId
})
const hasMyComment = computed(() => {
  return comments.value.some(c => c.userId === currentUser.value?.userId)
})

// 게시글 삭제
const deleteArticle = async () => {
  if (!confirm('정말 삭제하시겠습니까?')) return
  try {
    const token = localStorage.getItem('accessToken')
    await axios.delete(`/api/articles/${articleId}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    alert('게시글이 삭제되었습니다.')
    router.push(`/community/${boardId}`)
  } catch (e) {
    console.error('게시글 삭제 실패:', e)
    alert('삭제 중 오류가 발생했습니다.')
  }
}

// 수정 페이지로 이동 <- 이 부분 이따가 수정.....
const goToEdit = () => {
  router.push(`/articles/${articleId}/edit`)
}

// 게시글 조회
const fetchArticle = async () => {
  try {
    const token = localStorage.getItem('accessToken')
    const res = await axios.get(`/api/articles/${articleId}`, {
      headers: { Authorization: `Bearer ${token}` }
    })
    article.value = res.data.data
    additionalImages.value = article.value.attachments?.slice(1) || []
  } catch (err) {
    console.error('게시글 조회 실패:', err)
  }
}

// 댓글 조회
const loadComments = async () => {
  try {
    const token = localStorage.getItem('accessToken')
    const res = await axios.get('/api/comments', {
      params: { targetType: 'ARTICLE', targetId: articleId },
      headers: { Authorization: `Bearer ${token}` }
    })
    comments.value = res.data.data
  } catch (e) {
    console.error('댓글 불러오기 실패:', e)
  }
}

// 조회수 증가
const increaseViewCount = async () => {
  try {
    const token = localStorage.getItem('accessToken')
    await axios.patch(`/api/articles/${articleId}/view-count`, null, {
      headers: { Authorization: `Bearer ${token}` }
    })
  } catch (e) {
    console.error('조회수 증가 실패:', e)
  }
}

const getImageUrl = (path) => `http://localhost:8080${path}`

const goBackToBoard = () => {
  router.push(`/community/${boardId}`)
}

watch(() => articleId, async () => {
  await fetchArticle()
  await loadComments()
})

onMounted(async () => {
  await increaseViewCount()
  await fetchArticle()
  await loadComments()
})
</script>

<style scoped>
/* 필요 시 스타일 추가 */
</style>